<template>
    <div class="card">
    <div class=" block relative top-0 left-0 bg-blue-200 w-20rem ml-0 ">
        <div class="title">

            <h1 class="inline-block font-semibold"> Otros filtros </h1>
            <pv-button  label="Limpiar" link/>
        </div>
        <pv-divider/>
        <div class="content-filter">
            <span class="block font-normal text-100"> ¿Cuanto pesa su mascota?</span>

    <pv-button label="0-5Kg" severity="warning" />
            <pv-button class= "text-white" label="0-5Kg" severity="warning" />
            <pv-button label="0-5Kg" severity="warning" />
            <pv-button label="0-5Kg" severity="warning" />

            <pv-divider />

            <p>

            </p>

            <pv-divider />

            <p>

            </p>

            <pv-divider/>

            <p>

            </p>
        </div>
        </div>


</div>
</template>

<script>
export default {
name: "filter-content.component"
}
</script>

<style scoped>

:deep(.p-button .p-button-label){

    color: #FBB847;
    font-family: "Inter", sans-serif;
    margin-left: 5rem;
    text-align: left;
    font-weight:lighter;
    font-size: 11px;
    line-height: 7px;
    /* or 100% */
    align-content: end;
    position: relative;

    right: 0%

}


</style>