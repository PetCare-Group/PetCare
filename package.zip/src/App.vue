

<template>
    <FilterContent/>
<FooterContent/>


</template>


<script >
import FooterContent from "@/components/footer-content.component.vue";
import FilterContent from "@/components/filter-content.component.vue";
import {TutorialsApiService} from "@/learning/services/tutorials-api.service"
export default {
    name: 'App',
    components: { FooterContent, FilterContent},
    data() {
        return {
            articles: Array,
            errors: [],
            newsApi: new TutorialsApiService(),
        }
    },
    created(){
        console.log('created');
        this.getUsers();

    },
    methods: {
            // Fetch Articles for selected Source
            getUsers() {
                this.newsApi.getUser()
                    .then(response => {
                        this.articles = response.data;
                        console.log(response.data);
                    })
                    .catch(e => {
                        this.errors.push(e);
                    });

            }
        }
    }

</script>


<style scoped>

</style>
